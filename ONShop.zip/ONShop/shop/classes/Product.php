 <?php 
    $file_path = realpath(dirname(__FILE__));
    include_once ($file_path. '/../lib/Database.php');
    include_once ($file_path. '/../helpers/Format.php');
 ?>


<?php

class Product{
	
		    private $db;
        private $fm;

        public function __construct(){
              $this->db = new Database();
              $this->fm = new Format();

      }

   public function productInsert($data,$file){


   	$productName   = $this->fm->validation($data['productName']);
   	$catId         = $this->fm->validation($data['catId']);
   	$brandId       = $this->fm->validation($data['brandId']);
   	$body          = $this->fm->validation($data['body']);
   	$price         = $this->fm->validation($data['price']);
   	$type          = $this->fm->validation($data['type']);

	$productName   = mysqli_real_escape_string($this->db->link, $data['productName']);
	$catId         = mysqli_real_escape_string($this->db->link, $data['catId']);
	$brandId       = mysqli_real_escape_string($this->db->link, $data['brandId']);
	$body          = mysqli_real_escape_string($this->db->link, $data['body']);
	$price         = mysqli_real_escape_string($this->db->link, $data['price']);
	$type          = mysqli_real_escape_string($this->db->link, $data['type']);

    $permited  = array('jpg', 'jpeg', 'png', 'gif');
    $file_name = $file['image']['name'];
    $file_size = $file['image']['size'];
    $file_temp = $file['image']['tmp_name'];

    $div = explode('.', $file_name);
    $file_ext = strtolower(end($div));
    $unique_image = substr(md5(time()), 0, 10).'.'.$file_ext;
    $uploaded_image = "uploads/".$unique_image;
    if ($productName == "" || $catId == "" || $brandId == "" || $body == "" || $price == "" ||$file_name == "" || $type == "") {
      $msg = "<span class='error'>Fields must not be empty...!</span>";
                return $msg;

    }elseif ($file_size >1048567) {
      echo "<span class ='error'>image size should be lass then 1 Mb...!</span>";

    }elseif (in_array($file_ext, $permited) === false) {
      echo "<span class ='error'>You can upload only:-".implode(',', $permited)." </span>";

    }else{
         move_uploaded_file($file_temp, $uploaded_image);
         $query = "INSERT INTO table_product (productName,catId,brandId,body,price,image,type) VALUES('$productName','$catId','$brandId','$body',$price,'$uploaded_image','$type')";
          $inserted_row = $this->db->insert($query);
              if ($inserted_row) {
                $msg="<span class='success'>Product Inserted Successfully.</span>";
                return $msg;
              }else{
                $msg="<span class='error'>Product Not Inserted .</span>";
                return $msg;
              }
    }

   }
      
  public function getALLProduct(){

    $query = "SELECT p.*,c.catName,b.brandName
               FROM table_product as p, table_catagory as c, table_brand as b
               WHERE p.catId = c.catId AND p.brandId = b.brandId
               ORDER BY p.productId DESC";

    /*
    $query = "SELECT table_product.*, table_catagory.catName, table_brand.brandName
    FROM table_product
    INNER JOIN table_catagory
    ON table_product.catId = table_catagory.catId
    INNER JOIN table_brand
    ON table_product.brandId = table_brand.brandId
    ORDER BY table_product.productId DESC";
     */
    $result = $this->db->select($query);
    return $result;
   
  }

  public function getProById($id){
    $query ="SELECT * FROM  table_product WHERE productId = '$id'";
    $result = $this->db->select($query);
    return $result;
  }

  public function productUpdate($data, $file, $id){
    $productName   = $this->fm->validation($data['productName']);
    $catId         = $this->fm->validation($data['catId']);
    $brandId       = $this->fm->validation($data['brandId']);
    $body          = $this->fm->validation($data['body']);
    $price         = $this->fm->validation($data['price']);
    $type          = $this->fm->validation($data['type']);

  $productName   = mysqli_real_escape_string($this->db->link, $data['productName']);
  $catId         = mysqli_real_escape_string($this->db->link, $data['catId']);
  $brandId       = mysqli_real_escape_string($this->db->link, $data['brandId']);
  $body          = mysqli_real_escape_string($this->db->link, $data['body']);
  $price         = mysqli_real_escape_string($this->db->link, $data['price']);
  $type          = mysqli_real_escape_string($this->db->link, $data['type']);

    $permited  = array('jpg', 'jpeg', 'png', 'gif');
    $file_name = $file['image']['name'];
    $file_size = $file['image']['size'];
    $file_temp = $file['image']['tmp_name'];

    $div = explode('.', $file_name);
    $file_ext = strtolower(end($div));
    $unique_image = substr(md5(time()), 0, 10).'.'.$file_ext;
    $uploaded_image = "uploads/".$unique_image;
    if ($productName == "" || $catId == "" || $brandId == "" || $body == "" || $price == ""|| $type == "") {
      $msg = "<span class='error'>Fields must not be empty...!</span>";
                return $msg;

    }else{
      if (!empty($file_name)) {
        if ($file_size >1048567) {
          echo "<span class ='error'>image size should be lass then 1 Mb...!</span>";

        }elseif (in_array($file_ext, $permited) === false) {
          echo "<span class ='error'>You can upload only:-".implode(',', $permited)." </span>";

        }else{
             move_uploaded_file($file_temp, $uploaded_image);
             $query = "UPDATE table_product
                        SET
                        productName = '$productName',
                        catId       = '$catId',
                        brandId     = '$brandId',
                        body        = '$body',
                        price       = '$price',
                        image       = '$uploaded_image',
                        price       = '$price'
                        WHERE productId = '$id'";
              $updated_row = $this->db->update($query);
                  if ($updated_row) {
                    $msg="<span class='success'>Product Updated Successfully.</span>";
                    return $msg;
                  }else{
                    $msg="<span class='error'>Product Not Updated .</span>";
                    return $msg;
                  }
              }
            } else{
             $query = "UPDATE table_product
                        SET
                        productName = '$productName',
                        catId       = '$catId',
                        brandId     = '$brandId',
                        body        = '$body',
                        price       = '$price',
                        price       = '$price'
                        WHERE productId = '$id'";
              $updated_row = $this->db->update($query);
                  if ($updated_row) {
                    $msg="<span class='success'>Product Updated Successfully.</span>";
                    return $msg;
                  }else{
                    $msg="<span class='error'>Product Not Updated .</span>";
                    return $msg;
                  }

            }
          }
        }

      public function delProById($id){
        $query = "SELECT * FROM table_product WHERE productId = '$id'";
        $getData = $this->db->select($query);
        if ($getData) {
          while ($delImg = $getData->fetch_assoc()) {
            $dellink = $delImg['image'];
            unlink($delImg);
          }
        }

        $delquery = "DELETE FROM table_product WHERE productId = '$id'";
        $deldata = $this->db->delete($delquery);
        if ($deldata) {
          $msg="<span class='success'>Product Delete Successfully.</span>";
          return $msg;
        }else{
            $msg = "<span class='error'>Product Not Deleted...!</span>";
            return $msg;
          }

      }

      public function getFetureProduct(){
        $query ="SELECT * FROM table_product WHERE type = '0' ORDER BY productId DESC LIMIT 4";
        $result = $this->db->select($query);
        return $result;
      }

      public function getNewProduct(){
        $query ="SELECT * FROM table_product ORDER BY productId DESC LIMIT 4";
        $result = $this->db->select($query);
        return $result;
      }

      public function getSingleProduct($id){
         $query = "SELECT p.*,c.catName,b.brandName
               FROM table_product as p, table_catagory as c, table_brand as b
               WHERE p.catId = c.catId AND p.brandId = b.brandId AND p.productId='$id'";
        $result = $this->db->select($query);
        return $result;
      }

      public function LatestFormIphone(){
        $query ="SELECT * FROM table_product WHERE brandId = '1' ORDER BY productId DESC LIMIT 1";
        $result = $this->db->select($query);
        return $result;
      }

      public function LatestFormSamsung(){
        $query ="SELECT * FROM table_product WHERE brandId = '2' ORDER BY productId DESC LIMIT 1";
        $result = $this->db->select($query);
        return $result;
      }

      public function LatestFormAcer(){
        $query ="SELECT * FROM table_product WHERE brandId = '3' ORDER BY productId DESC LIMIT 1";
        $result = $this->db->select($query);
        return $result;
      }

      public function LatestFormCanon(){
        $query ="SELECT * FROM table_product WHERE brandId = '4' ORDER BY productId DESC LIMIT 1";
        $result = $this->db->select($query);
        return $result;
      }

      public function productByCat($id){
        $catId     = mysqli_real_escape_string($this->db->link, $id);
        $query  ="SELECT * FROM  table_product WHERE catId = '$catId'";
        $result = $this->db->select($query);
        return $result;
      }










}
?>