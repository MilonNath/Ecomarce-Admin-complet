<?php include 'inc/header.php' ?>
<style>
	.notfound{};
	.content h2{
		font-size: 27px;
     color: red;
     font-family: 'Monda', sans-serif;
     text-align: center;
	}
	.notfound h2 span{
		display: block; 
		color: red; 
		font-size: 170px;
		text-align: center;
	}

</style>

 <div class="main">
    <div class="content">
    		<div class="notfound">
    			<h2><span>404</span>Not Found</h2>
    		</div>
    		
	
       <div class="clear"></div>
    </div>
 </div>

<?php include 'inc/footer.php' ?>