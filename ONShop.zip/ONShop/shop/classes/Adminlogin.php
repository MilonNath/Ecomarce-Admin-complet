 <?php 
    
    $file_path = realpath(dirname(__FILE__));
    include_once ($file_path. '/../lib/Session.php');
    Session::checkLogin();
    include_once ($file_path. '/../lib/Database.php');
    include_once ($file_path. '/../helpers/Format.php');

 ?>

<?php

    class Adminlogin{
    	private $db;
    	private $fm;

        public function __construct(){
              $this->db = new Database();
              $this->fm = new Format();

          }

          public function Adminlogin($adminUser,$adminPass){
          	$adminUser = $this->fm->validation($adminUser);
          	$adminPass = $this->fm->validation($adminPass);

            $adminUser  = mysqli_real_escape_string($this->db->link,$adminUser);
            $adminPass  = mysqli_real_escape_string($this->db->link,$adminPass);

            if (empty($adminUser) || empty($adminPass)) {
                $loginmsg = "Username or password must not be empty...!";
                return $loginmsg;
            }else{
                $query = "SELECT * FROM  table_admin WHERE adminUser = '$adminUser' AND adminPass = '$adminPass'";
                $result = $this->db->select($query);
                if ($result != false) {
                    $value = $result->fetch_assoc();
                    Session::set("adminlogin",true);
                    Session::set("adminId",   $value['adminId']);
                    Session::set("adminUser", $value['adminUser']);
                    Session::set("adminName", $value['adminName']);
                   // Session::set("adminPass", $value['$adminPass']);
                    header("Location:dashbord.php");
                }else{
                    $loginmsg = "Username or password  not match...!";
                    return $loginmsg;
                }
            }

          }
    }

?>