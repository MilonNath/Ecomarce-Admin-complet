<?php include 'inc/header.php' ?>
<?php 
  if (isset($_GET['delquentitypro'])){
  	  $delId = preg_replace('/[^-a-zA-Z0-9_]/', '', $_GET['delquentitypro']);
  	  $delQproduct= $ct->delProductByCart($delId);
  }
?>
<?php 
 if($_SERVER['REQUEST_METHOD'] == 'POST'){
	    $cartId = $_POST['cartId'];
	    $quantity = $_POST['quantity'];
	    $updateCart = $ct->updateCartQuentity($cartId, $quantity);
	    if ($quantity <=0) {
	    	$delQproduct= $ct->delProductByCart($cartId);
	    }
	}
?>
<?php 
   if (!isset($_GET['lodeid'])) {
   	 echo "<meta http-equiv='refresh' content='0;URL=?lodeid=live'/>";
   }
?>

 <div class="main">
    <div class="content">
    	<div class="cartoption">		
			<div class="cartpage">
			    	<h2>Your Cart</h2>
			    	<?php 
			    	  if (isset($updateCart)) {
			    	  	  echo $updateCart;
			    	  }
			    	  if (isset($delQproduct)) {
			    	  	  echo $delQproduct;
			    	  }
			    	?>
						<table class="tblone">
							<tr>
								<th width="5%">SL</th>
								<th width="30%">Product Name</th>
								<th width="10%">Image</th>
								<th width="15%">Price</th>
								<th width="15%">Quantity</th>
								<th width="15%">Total Price</th>
								<th width="10%">Action</th>
							</tr>

							<?php
							  $getCpro = $ct->getCartProduct();
							  if ($getCpro) {
							  	  $i = 0;
							  	  $sum = 0;
							  	  $qty = 0;
							  	  while ($result = $getCpro->fetch_assoc()) {
							  	  	$i++;							  	 
							?>

							<tr>
								<td><?php  echo $i; ?></td>
								<td><?php  echo $result['productName']; ?></td>
								<td><img src="admin/<?php echo $result['image']?>" alt=""/></td>
								<td>$<?php  echo $result['price'] ?></td>
						<td>
							<form action="" method="post">
								<input type="hidden" name="cartId" value="<?php echo $result['cartId']; ?>"/>
								<input type="number" name="quantity" value="<?php echo $result['quantity']; ?>"/>
								<input type="submit" name="submit" value="Update"/>
							</form>
						</td>
								<td>$<?php
								  $totalPrize = $result['price'] * $result['quantity'];
								    echo  $totalPrize;
								?></td>
								<td><a onclick="return confirm('Are u sure to delete...?')" href="?delquentitypro=<?php echo $result['cartId']; ?>">X</a></td>
							</tr>
							<?php 
							$qty = $qty + $result['quantity'];
							$sum = $sum + $totalPrize;
							Session::set("qty", $qty);
							Session::set("sum", $sum);
							?>
						<?php } } ?>
							
						</table>
						<?php 
						  $getCrtData = $ct->CheckCartTable();
								  if ($getCrtData) {
						?>
						<table style="float:right;text-align:left;" width="40%">
							<tr>
								<th>Sub Total : </th>
								<td><?php echo $sum;?></td>
							</tr>
							<tr>
								<th>VAT : </th>
								<td>10%</td>
							</tr>
							<tr>
								<th>Grand Total :</th>
								<td>
									<?php 
	                           $vat = $sum * 0.1;
	                           $gtotal = $sum + $vat;
	                           echo $gtotal;
							       ?> 
							   </td>
							</tr>
					   </table>
					<?php } else {
              header("location:index.php");
						//echo "Empty Cart ! Please Shop Now.";
					} ?>

					</div>
					<div class="shopping">
						<div class="shopleft">
							<a href="index.php"> <img src="images/shop.png" alt="" /></a>
						</div>
						<div class="shopright">
							<a href="login.php"> <img src="images/check.png" alt="" /></a>
						</div>
					</div>
    	</div>  	
       <div class="clear"></div>
    </div>
 </div>
<?php include 'inc/footer.php' ?>